window.setTimeout(function() {
	document.getElementById('myButton').addEventListener ( 'click', function(){
		window.open("res/myAction.html");
	});
}, 500);